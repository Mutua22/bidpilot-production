# EssayPro Bot — Solo — Authorized Automation

This Chrome Manifest V3 extension monitors a configured authorized job feed, detects new jobs, applies filters, generates bids, optionally posts to a documented authorized submission endpoint, and records statistics.

It does not bypass CAPTCHA, authentication, anti-bot systems, rate limits, or other access controls.

Testing: extract the folder, open chrome://extensions, enable Developer mode, choose Load unpacked, select the folder, then activate the license in Settings.

Production: publish the extension through the Chrome Web Store. Keep the existing M-Pesa checkout and use product="essaypro" for EssayPro licenses.
