// BidPilot production license server
const BIDPILOT_LICENSE_SERVER = "https://bidpilot-production-production.up.railway.app";
